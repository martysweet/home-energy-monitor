/*
 * Copyright 2010-2018 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 */

exports.start = function start(runtime) {
    runtime.getWorkAndInvoke();
};
